<?php
include'header.php';
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body style="background-color: #2c3e50;">

  <!-- Main Content Section -->
  <section class="main-content section dashboard">
    <div class="container-fluid">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="row">
            
            <div class="ol-lg-8 col-md-10 mx-auto welcome-text">
              <img src="logo2.png" class="img-fluid" alt="Logo Image" style="margin-top: 20%; width: 20%;height: 20%; margin-left: 20%;">
              <br><br>
               <h4 style="color: white; margin-left:15%;">WELCOME TO DDIN!!</h4><br>
              <h6 style="color:white;">Some welcome text about DDIN Group Ltd <br>and its services. Unleash Your Competitive Edge with<br> Our Robust Agency Network Platform. Join DDIN and connect with <br>a Network of the Best, where excellence is the standard and innovation drives success.</h6><br>
                <img src="ud.png" class="img-fluid" alt="Some Image" style="margin-left:0%"><br>
               
        
           
          </div>
        </div><!-- End Left side columns -->

      </div>
    </div>
  </section>
  <!-- Footer (optional) -->
  <footer class="text-white text-center p-3" style="background-color:#5d6f7d;">
     <p style="text-align: center; margin-left:%;color:white;">Powered by DDIN Group Ltd © 2024</p>
    
  </footer>

  <!-- Bootstrap JS -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>
